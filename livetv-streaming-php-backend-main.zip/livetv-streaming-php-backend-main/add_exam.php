<?php include "header.php"; ?>
<div class="content_main">
	<h1>Add Exam</h1>
</div>
<?php include "footer.php" ?>
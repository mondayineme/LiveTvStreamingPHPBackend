<?php 
	$conn = mysqli_connect("localhost","root","root","tvappdemo") or die("DB Connection Failed.");

?>
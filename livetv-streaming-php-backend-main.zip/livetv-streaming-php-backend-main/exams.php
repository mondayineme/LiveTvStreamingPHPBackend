<?php include "header.php"; ?>
<div class="content_main">
	<h1>All Exams</h1>
</div>
<?php include "footer.php" ?>